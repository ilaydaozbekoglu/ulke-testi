﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testUygulamasi
{
    public partial class Form1 : Form
    {
        string[,] sorular = new string[5, 6];
        int index = 0;
        int tiklama = 0;
        int ds = 0, ys =0;
        public Form1()
        {
            InitializeComponent();
            lbl_acıklama.Text = "Ülke bilmece oyununa hoş geldiniz. Ülke resimlerini görmek için yana tıklayınız!";

            sorular[0, 0] = "1-Resimdeki ülke hangisidir?";
            sorular[0, 1] = "Bulgaristan";
            sorular[0, 2] = "Türkiye";
            sorular[0, 3] = "Rusya";
            sorular[0, 4] = "Yunanistan";
            sorular[0, 5] = "Türkiye";

            sorular[1, 0] = "2-Resimdeki ülke hangisidir?";
            sorular[1, 1] = "Peru";
            sorular[1, 2] = "Şili";
            sorular[1, 3] = "Bolivya";
            sorular[1, 4] = "Paraguay";
            sorular[1, 5] = "Bolivya";
              
            sorular[2, 0] = "3-Resimdeki ülke hangisidir?";
            sorular[2, 1] = "İspanya";
            sorular[2, 2] = "İngiltere";
            sorular[2, 3] = "Belçika";
            sorular[2, 4] = "İrlanda";
            sorular[2, 5] = "İrlanda";

            sorular[3, 0] = "4-Resimdeki ülke hangisidir?";
            sorular[3, 1] = "Pakistan";
            sorular[3, 2] = "Myanmar";
            sorular[3, 3] = "Afganistan";
            sorular[3, 4] = "Hindistan";
            sorular[3, 5] = "Myanmar";

            sorular[4, 0] = "5-Resimdeki ülke hangisidir?";
            sorular[4, 1] = "Sudan";
            sorular[4, 2] = "Libya";
            sorular[4, 3] = "Çad";
            sorular[4, 4] = "Mısır";
            sorular[4, 5] = "Sudan";

            soruListele();

        }
        public void soruListele()
        {
            if (index < sorular.GetLength(0)) {
                lbl_soru.Text = sorular[index, 0];
                radioButton1.Text = sorular[index, 1];
                radioButton2.Text = sorular[index, 2];
                radioButton3.Text = sorular[index, 3];
                radioButton4.Text = sorular[index, 4];
            }
            else
            {
                groupBox1.Visible = false;
                button1.Enabled = false;
                if (ds == 5)
                {
                    lbl_soru.Text = "Tebrikler, hepsini doğru bildiniz!";
                }
                 else if (ds >= 1)
                {
                    lbl_soru.Text = "Daha iyisini yapabilirsin!";
                }

                else if(ds == 0){
                    lbl_soru.Text = "Dünya hakkında biraz daha bilgi sahibi olmalısın...";
                }
               
                

            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        { if (tiklama == 0)
            {
                lbl_resimno.Visible = true;
                lbl_resimno.Text = "1. Resim";
                pictureBox1.Image = Image.FromFile(@"C:\Users\ilayd\source\repos\testUygulamasi\testUygulamasi\resimler\turkiye.JPG");
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
                

            foreach(RadioButton rbt in groupBox1.Controls.OfType<RadioButton>())
            {
                if (rbt.Checked)
                {
                    tiklama++;
                    if (rbt.Text.Equals(sorular[index, 5]))
                    {
                        ds++;
                        lbl_dogru.Visible = true;
                    }
                    else
                    {
                        ys++;                    
                        lbl_yanlis.Visible = true;
                    }
                    lbl_dogru.Text = "Doğru sayısı:" + ds;
                    lbl_yanlis.Text = "Yanlış sayısı:" + ys;
                    break;

                }
            }
            if (tiklama == 0)
            {
                lbl_resimno.Visible = true;
                lbl_resimno.Text = "1. Resim";
                pictureBox1.Image = Image.FromFile(@"C:\Users\ilayd\source\repos\testUygulamasi\testUygulamasi\resimler\turkiye.JPG");
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else if (tiklama == 1)
            {
                lbl_resimno.Visible = true;
                lbl_resimno.Text = "2. Resim";
                pictureBox1.Image = Image.FromFile(@"C:\Users\ilayd\source\repos\testUygulamasi\testUygulamasi\resimler\bolivya.JPG");
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }

            else if (tiklama == 2)
            {
                lbl_resimno.Visible = true;
                lbl_resimno.Text = "3. Resim";
                pictureBox1.Image = Image.FromFile(@"C:\Users\ilayd\source\repos\testUygulamasi\testUygulamasi\resimler\irlanda.JPG");
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }

            else if (tiklama == 3)
            {
                lbl_resimno.Visible = true;
                lbl_resimno.Text = "4. Resim";
                pictureBox1.Image = Image.FromFile(@"C:\Users\ilayd\source\repos\testUygulamasi\testUygulamasi\resimler\myanmar.JPG");
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else if (tiklama == 4)
            {
                lbl_resimno.Visible = true;
                lbl_resimno.Text = "5. Resim";
                pictureBox1.Image = Image.FromFile(@"C:\Users\ilayd\source\repos\testUygulamasi\testUygulamasi\resimler\sudan.JPG");
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else if (tiklama == 5)
            {
                //lbl_resimno.Text = "1. Resim";
                pictureBox1.Image = Image.FromFile(@"C:\Users\ilayd\source\repos\testUygulamasi\testUygulamasi\resimler\dünya.jpg");
            }

           
            index++;
            soruListele();

        }
    }
}
